#pykaHFM

Implementace algoritmu kaHFM.